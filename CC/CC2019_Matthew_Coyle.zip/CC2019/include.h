#pragma once
#include <iostream>
#include <ostream>
#include <sstream>
#include <string>
#include <memory>
#include <vector>
#include <list>

typedef unsigned int N;
typedef std::string str;
typedef std::vector<std::string> vstr;